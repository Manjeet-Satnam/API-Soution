﻿using System;
namespace Winning_Test_API.Models
{
    public class ProductDto
    {
        public ProductDto()
        {
        }

        public int id { get; set; }
        public string sku { get; set; }
        public string name { get; set; }
        public double price { get; set; }
       // public AttributeEntity attribute { get; set; }

    }
}
