﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Winning_Test_API.Models;
using Winning_Test_DAL.Models;
using Winning_Test_Services.Interface;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Winning_Test_API.Controllers
{
    [Route("api/[controller]/[action]")]
    public class ProductController : Controller
    {
        /// <summary>
        /// Dependency Injection is used here
        /// </summary>
        private readonly IProductService _productService;
        public ProductController(IProductService productService)
        {
            _productService = productService;
        }

        /// <summary>
        /// Get All the Product
        /// </summary>
        /// <returns>List of the products</returns>
       
        [HttpGet]
       
        public ActionResult<IEnumerable<ProductDto>> GetPoduct()
        {
            try
            {

                return Ok(_productService.GetProducts());
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Get Product based on the price minimum/ maximum
        /// </summary>
        /// <param name="filter">min/max</param>
        /// <returns>product with min/ max price</returns>
        [HttpGet]
        public ActionResult<IEnumerable<ProductDto>> GetProductByPrice([FromQuery] FilterProduct filter)
        {
            try
            {

                return Ok(_productService.GetProductByPriceMinMax(filter));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Get  fantastic attribute 
        /// </summary>
        /// <param name="fantastic">true/false</param>
        /// <returns> product with fantastic attribute/returns>

        [HttpGet]
        public ActionResult<IEnumerable<ProductDto>> GetProductByByFantasticAttribute([FromQuery] bool fantastic)
        {
            try
            {

                return Ok(_productService.GetProductByFantasticAttribute(fantastic));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        /// <summary>
        /// Get Rating based on the rating value minimum/maximum
        /// </summary>
        /// <param name="rating">min/max</param>
        /// <returns>product with rating value/returns>

        [HttpGet]
        public ActionResult<IEnumerable<ProductDto>> GetProductByRating([FromQuery] FilterProduct rating)
        {
            try
            {

                return Ok(_productService.GetProductByRatingAttribute(rating));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}
