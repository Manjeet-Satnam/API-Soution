﻿USED TECHNOLOGY:
Visual Studio 2019(MAC Pro)
.Net core 3.1
Swagger UI
MongoDB(connection is created but not fetch data from database).
Product Json file is in the solution which provide aa the details of product.

Dependancy Injection is used.

xUnit Testing is done.

Run the solution with swagger UI and use filter min/ max for Price and Rating.
Use true/ false for  fantastic attribute.
