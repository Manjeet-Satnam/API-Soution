﻿using System;
namespace Winning_Test_DAL.Models
{
    public class FilterProduct
    {
        public FilterProduct()
        {
        }
        public bool min { get; set; }
        public bool max { get; set; }
    }
}
