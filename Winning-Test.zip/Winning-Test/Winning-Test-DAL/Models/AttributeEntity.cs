﻿using System;
namespace Winning_Test_DAL.Models
{
    public class AttributeEntity
    {
        public AttributeEntity()
        {
        }
         public FantasticEntity  fantastic { get; set; }
         public RatingEntity rating { get; set; }

    }
}
