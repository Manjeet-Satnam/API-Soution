﻿using System;
namespace Winning_Test_DAL.Models
{
    public class FantasticEntity
    {
        public FantasticEntity()
        {
        }
    

        public bool value { get; set; }
        public int type { get; set; }
        public string name { get; set; }
    }
}
