﻿using System;
using MongoDB.Driver;
using Winning_Test_DAL.Models;
using Winning_Test_Services.Interface;
using Winning_Test_Services.Services;
using Xunit;

namespace Winning_Test_xUnitTest
{
    public class ProductTest
    {
        private ProductService _productService;
        IProductDbContext dbContext;
        public ProductTest()
        {
            if (_productService == null)
            {
                dbContext = new ProductDbContext(null);
                    
                    _productService = new ProductService(dbContext);
            }
        }
      
      

        /// <summary>
        /// unit testing for get product by max price
        /// </summary>
        [Fact]
        public void GetProductByMaxPrice()
        {
           

               FilterProduct filter = new FilterProduct();
            filter.max= true;

            var maxPrice=   _productService.GetProductByPriceMinMax(filter);
            Assert.Equal(998.52m, maxPrice.price);

        }
        /// <summary>
        /// unit testing for product get by min price
        /// </summary>
        [Fact]
        public void GetProductByMinPrice()
        {
           
            FilterProduct filter = new FilterProduct();
            filter.min = true;

            var mixPrice = _productService.GetProductByPriceMinMax(filter);
            Assert.Equal(101.62m, mixPrice.price);


        }
        /// <summary>
        /// unit testing for product get by min rating
        /// </summary>
        [Fact]
        public void GetProductByMinRating()
        {
           
            FilterProduct filter = new FilterProduct();
            filter.min = true;

            var minRating = _productService.GetProductByRatingAttribute(filter);
            Assert.Equal(1, minRating.attribute.rating.value);


        }
        /// unit testing for product get by maximum rating
        /// </summary>
        [Fact]
        public void GetProductByMaxRating()
        {
            FilterProduct filter = new FilterProduct();
            filter.max = true;
            double expectedvalue = 5;
            var maxRating = _productService.GetProductByRatingAttribute(filter);
            Assert.Equal(expectedvalue, maxRating.attribute.rating.value);


        }
    }
}
