﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;
using MongoDB.Driver;
using Winning_Test_DAL.Models;
using Winning_Test_Services.Interface;
using Winning_Test_Services.Model;

namespace Winning_Test_Services.Services
{
    public class ProductService : IProductService
    {
        private readonly IMongoCollection<ProductEntity> _product;

        /// <summary>
        /// Dependency Injection
        /// </summary>
        /// <param name="dbContext"></param>

        public ProductService(IProductDbContext dbContext)
        {
            _product = dbContext.GetProductCollection();

        }

        public List<ProductEntity> productEntities()
        {
            List<ProductEntity> products = new List<ProductEntity>();
            var webClient = new WebClient();
            string fileName = "MOCK_DATA.json";
            string path = Path.Combine(Environment.CurrentDirectory, @"ProductJsonFile", fileName);
            var json = webClient.DownloadString(path);
            products =  JsonSerializer.Deserialize<List<ProductEntity>>(json);

            return products;
        }


        /// <summary>
        /// Get All Products from MongoDb
        /// </summary>
        /// <returns></returns>

        public IEnumerable<ProductEntity> GetProducts()
        {
            List<ProductEntity> products = new List<ProductEntity>();

            try
            {
               
                products = productEntities();
                return products;
                //return _product.Find(ProductEntity => true).ToList();
            }
            catch (Exception ex)
            {
                throw new APIException(ex.Message);
            }
        }

        /// <summary>
        /// Get product by Price
        /// </summary>
        /// <returns>return min/max price</returns>

        public ProductEntity GetProductByPriceMinMax(FilterProduct filter)
        {
            ProductEntity entity = new ProductEntity();
            List<ProductEntity> products = new List<ProductEntity>();

            try
            {

                products = productEntities();
                if (filter.max)
                {
                    // query used for MongoDb data --- Start
                    // var sort = Builders<ProductEntity>.Sort.Descending("price"); //build sort object   
                    //entity = _product.Find(ProductEntity => true).Sort(sort).FirstOrDefault(); //apply it to collection

                    //-----end

                    var maxValue = products.Max(o => o.price);
                    entity = products.Where(o => o.price == maxValue).FirstOrDefault();
                }
                else if (filter.min)
                {
                    // query used for MongoDb data --- Start
                    // var sort = Builders<ProductEntity>.Sort.Ascending("price"); //build sort object   
                    //entity = _product.Find(ProductEntity => true).Sort(sort).FirstOrDefault(); //apply it to collection
                    //-----end

                    var minValue = products.Min(o => o.price);
                    entity = products.Where(o => o.price == minValue).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                throw new APIException(ex.Message);
            }


            return entity;
        }

        /// <summary>
        /// Get product by fantastic attribute
        /// </summary>
        /// <returns>return fantastic attribute</returns>

        public IEnumerable<ProductEntity> GetProductByFantasticAttribute(bool fantastic) { 


        // return _product.Find<ProductEntity>(product => product.Attribute.Fantastic.Value == fantastic).ToList(); //Code for database query
       List< ProductEntity >entity = new List<ProductEntity>();
        List<ProductEntity> products = new List<ProductEntity>();

            try
            {
                products = productEntities();

                entity= products.Where(o => o.attribute.fantastic.value == fantastic).ToList();
                return entity;

            }
            catch (Exception ex)
            {
                throw new APIException(ex.Message);

            }
         
    }
        /// <summary>
        /// Get product by rating attribute min / max.
        /// </summary>
        /// <returns>return  min/max rating</returns>

        public ProductEntity GetProductByRatingAttribute(FilterProduct rating)
        {
            // _product.Find<ProductEntity>(product => product.Attribute.Fantastic.Value == rating).ToList();//Code for DB query

            ProductEntity entity = new ProductEntity();
            List<ProductEntity> products = new List<ProductEntity>();

            try
            {

                products = productEntities();
                if (rating.max)
                {
                    var maxValue = products.Max(o => o.attribute.rating.value);
                    entity = products.Where(o => o.attribute.rating.value == maxValue).FirstOrDefault();
                }
                else if (rating.min)
                {

                    var minValue = products.Min(o => o.attribute.rating.value);
                    entity = products.Where(o => o.attribute.rating.value == minValue).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                throw new APIException(ex.Message);
            }

            return entity;

        }



    }
}
