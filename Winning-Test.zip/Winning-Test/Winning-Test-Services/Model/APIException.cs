﻿using System;
namespace Winning_Test_Services.Model
{
    public class APIException:Exception
    {
        public int HttpStatusCode { get; set; }

        public APIException(string message):base(message)
        {
            HttpStatusCode = (int)System.Net.HttpStatusCode.InternalServerError;
        }

    }
}
