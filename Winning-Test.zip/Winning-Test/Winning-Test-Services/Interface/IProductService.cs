﻿using System;
using System.Collections.Generic;
using Winning_Test_DAL.Models;

namespace Winning_Test_Services.Interface
{
    public interface IProductService
    {
        IEnumerable<ProductEntity> GetProducts();
        ProductEntity GetProductByPriceMinMax(FilterProduct filter);
        IEnumerable<ProductEntity> GetProductByFantasticAttribute(bool fantastic);
        ProductEntity GetProductByRatingAttribute(FilterProduct rating);

}
}
